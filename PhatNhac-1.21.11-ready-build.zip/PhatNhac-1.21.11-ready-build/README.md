# PhatNhac — Minecraft 1.21.11 Fabric

Bản source này đã được chuẩn hóa để build thành JAR bằng Gradle.

## Yêu cầu
- Minecraft 1.21.11
- Fabric Loader 0.18.1+
- Fabric API 0.141.3+1.21.11
- Java 21
- Gradle 8.x (khuyến nghị dùng Gradle Wrapper nếu môi trường build có sẵn wrapper)

## Build
Mở terminal tại thư mục project rồi chạy:

```bash
gradle build
```

Windows PowerShell/CMD cũng dùng:

```bat
gradle build
```

Sau khi build thành công, file nằm tại:

```text
build/libs/PhatNhac-0.2.0.jar
```

File `-sources.jar` là source, không bỏ vào thư mục mods.

## Cài vào Minecraft
Đặt `PhatNhac-0.2.0.jar` vào:

```text
mods/
```

Phải có Fabric Loader + Fabric API tương ứng với Minecraft 1.21.11.

## Mở menu
Trong game nhấn `P`.

## Lưu ý về environment
Mod này có GUI và keybind nên entrypoint là **client**. Không đổi `environment` thành `*`: làm vậy không khiến GUI client chạy trên dedicated server và có thể gây lỗi khi server nạp mod.

## YouTube
Bản hiện tại chỉ nhận diện Video ID và quản lý trạng thái giao diện. Nó **chưa nhúng trình phát YouTube thật** và không tải/rip âm thanh từ YouTube.
