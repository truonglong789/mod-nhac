package com.phatnhac.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import org.lwjgl.glfw.GLFW;

public class PhatNhacClient implements ClientModInitializer {
    public static final String MOD_ID = "phatnhac";

    @Override
    public void onInitializeClient() {
        KeyMapping open = KeyBindingHelper.registerKeyBinding(new KeyMapping(
            "key.phatnhac.open", GLFW.GLFW_KEY_P, "key.categories.phatnhac"
        ));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (open.consumeClick()) client.setScreen(new PhatNhacScreen(client.screen));
        });
    }
}
