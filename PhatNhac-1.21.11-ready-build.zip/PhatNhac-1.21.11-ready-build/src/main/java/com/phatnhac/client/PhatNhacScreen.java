package com.phatnhac.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class PhatNhacScreen extends Screen {
    private final Screen parent;
    private EditBox urlBox;
    private String videoId;
    private String status = "Dán link YouTube rồi bấm PHÁT";
    private boolean videoVisible = true;
    private boolean playing = false;
    private int volume = 70;

    public PhatNhacScreen(Screen parent) {
        super(Component.literal("PhatNhac"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int cx = width / 2;
        int top = Math.max(35, height / 2 - 95);

        urlBox = new EditBox(font, cx - 155, top, 310, 20, Component.literal("YouTube URL"));
        urlBox.setHint(Component.literal("https://youtube.com/watch?v=..."));
        addRenderableWidget(urlBox);

        addRenderableWidget(Button.builder(Component.literal("PHÁT"), b -> {
            String id = YouTubeUrl.videoId(urlBox.getValue());
            if (id == null) {
                videoId = null;
                status = "Link YouTube không hợp lệ";
            } else {
                videoId = id;
                playing = true;
                status = "Video ID: " + id;
            }
        }).bounds(cx - 45, top + 27, 90, 20).build());

        addRenderableWidget(Button.builder(Component.literal("▶ / ⏸"), b -> {
            if (videoId == null) status = "Chưa có video";
            else {
                playing = !playing;
                status = (playing ? "Đang phát • " : "Đã tạm dừng • ") + videoId;
            }
        }).bounds(cx - 155, top + 60, 90, 20).build());

        addRenderableWidget(Button.builder(Component.literal("Video: ON"), b -> {
            videoVisible = !videoVisible;
            b.setMessage(Component.literal("Video: " + (videoVisible ? "ON" : "OFF")));
        }).bounds(cx - 60, top + 60, 90, 20).build());

        addRenderableWidget(Button.builder(Component.literal("Volume: 70%"), b -> {
            volume += 10;
            if (volume > 100) volume = 0;
            b.setMessage(Component.literal("Volume: " + volume + "%"));
        }).bounds(cx + 40, top + 60, 115, 20).build());

        addRenderableWidget(Button.builder(Component.literal("Playlist"), b ->
            status = "Playlist: sẵn sàng để nối với player"
        ).bounds(cx - 70, top + 92, 140, 20).build());

        addRenderableWidget(Button.builder(Component.literal("Đóng"), b -> onClose())
            .bounds(cx - 45, top + 123, 90, 20).build());
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        renderBackground(g, mouseX, mouseY, delta);
        int cx = width / 2;
        int top = Math.max(22, height / 2 - 125);

        g.fill(cx - 180, top, cx + 180, top + 175, 0xDD101218);
        g.drawCenteredString(font, "PhatNhac", cx, top + 9, 0xFFFFFF);

        if (videoVisible) {
            g.fill(cx - 150, top + 25, cx + 150, top + 58, 0xFF20242B);
            g.drawCenteredString(font,
                videoId == null ? "YouTube Player" : "YouTube • " + videoId,
                cx, top + 37, 0xD0D0D0);
        } else {
            g.drawCenteredString(font, "🎵 Video đang ẩn", cx, top + 40, 0xD0D0D0);
        }

        g.drawCenteredString(font, status, cx, top + 150, 0xAAAAAA);
        super.render(g, mouseX, mouseY, delta);
    }

    @Override
    public void onClose() {
        Minecraft.getInstance().setScreen(parent);
    }
}
