package com.phatnhac.client;

import java.net.URI;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class YouTubeUrl {
    private static final Pattern SHORT = Pattern.compile("^[A-Za-z0-9_-]{11}$");
    private static final Pattern WATCH = Pattern.compile("[?&]v=([A-Za-z0-9_-]{11})");
    private static final Pattern SHORT_URL = Pattern.compile("youtu\\.be/([A-Za-z0-9_-]{11})");
    private static final Pattern EMBED = Pattern.compile("(?:youtube(?:-nocookie)?\\.com)/(?:embed|shorts)/([A-Za-z0-9_-]{11})");

    private YouTubeUrl() {}

    public static String videoId(String input) {
        if (input == null) return null;
        String s = input.trim();
        if (SHORT.matcher(s).matches()) return s;

        Matcher m = WATCH.matcher(s);
        if (m.find()) return m.group(1);

        m = SHORT_URL.matcher(s);
        if (m.find()) return m.group(1);

        m = EMBED.matcher(s);
        if (m.find()) return m.group(1);

        try {
            URI u = URI.create(s);
            String host = u.getHost();
            String path = u.getPath();
            if (host != null && host.endsWith("youtube.com") && path != null) {
                String[] parts = path.split("/");
                if (parts.length >= 3 && ("embed".equals(parts[1]) || "shorts".equals(parts[1]))
                        && SHORT.matcher(parts[2]).matches()) return parts[2];
            }
        } catch (IllegalArgumentException ignored) {}
        return null;
    }
}
